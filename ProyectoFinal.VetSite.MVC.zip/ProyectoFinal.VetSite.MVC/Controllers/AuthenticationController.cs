﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.Scripting;
using Microsoft.EntityFrameworkCore;
using ProyectoFinal.Repositorio;
using ProyectoFinal.VetSite.MVC.Models;
using System.Diagnostics;
using System.Security.Claims;
using System.Security;


namespace ProyectoFinal.VetSite.MVC.Controllers
{
    public class AuthenticationController : Controller
    {
        private readonly Contexto _contexto;
        public AuthenticationController(Contexto contexto) => _contexto = contexto;

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> Login(string nombre, string clave)
        {
            var usuario = await _contexto.Usuarios
                .FirstOrDefaultAsync(u => u.Nombre == nombre);

            if (!await _contexto.ValidarClaveAsync(usuario.UsuarioID, clave))
            {
                ModelState.AddModelError(string.Empty, "Usuario no encontrado");
                return View();
            }

            // Set authentication cookie
            var claims = new List<Claim>
            {
                new(ClaimTypes.Name, usuario.Nombre)
            };

            var identity = new ClaimsIdentity(claims, "Cookies");
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

            return RedirectToAction("Index", "Home");
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }

    }
}
