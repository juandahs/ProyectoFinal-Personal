﻿namespace ProyectoFinal.VetSite.MVC.Models
{
    public class LoginViewModel
    {
        public string Nombre { get; set; }
        public string Clave { get; set; }
    }

}
